<?php
echo '<img src="uploads/attendance.jpeg" alt="icon" />';
?>